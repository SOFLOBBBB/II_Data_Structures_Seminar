#ifndef DISPERSION_HPP
#define DISPERSION_HPP

#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
using namespace std;

#define NUMREGISTROS 100
#define CONTENEDOR   4

class Soporte
{
    private:
        char id[ 12 ];
        char problema[ 35 ];
        char fecha[ 25 ];
        char estado[ 20 ];

        int dispersion( const char llave[ 12 ] );
        long int buscarId( const string & );

    public:
        Soporte( void );
        Soporte( const Soporte & );

        void setId( const string & );
        void setProblema( const string & );
        void setFecha( const string & );
        void setEstado( const string & );

        friend ostream &operator<<( ostream &, const Soporte & );

        bool contiene( const string & );
        void genera( void );

        bool agregar( const Soporte & );
        void mostrar( void );
        bool buscar( const string &, Soporte & );
        bool eliminar( const string &, Soporte & );
        bool modificar( const string &, const Soporte & );

        void mostrarIndice( void );
        Soporte pedirRegistro( void );
        void menuOpc (void);
};


#endif // SUPPORT_HPP
