#ifndef ASSERT_HPP_INCLUDED
#define ASSERT_HPP_INCLUDED

#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cstring>

void Assert(bool, std::string);

#endif // ASSERT_HPP_INCLUDED
