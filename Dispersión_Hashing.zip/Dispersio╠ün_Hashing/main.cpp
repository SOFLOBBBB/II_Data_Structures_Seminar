#include "Interfaz.hpp"

Interfaz Menu1;

int main()
{
    Menu1.Menu();
}
