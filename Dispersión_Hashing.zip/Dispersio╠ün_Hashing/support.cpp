#include "support.hpp"

//Setters y getters

void Soporte::setId( const string &valorId )
{
    int longitud = valorId.size();
    longitud = ( longitud < 12 ? longitud : 11 );
    valorId.copy( id, longitud );
    id[ longitud ] = '\0';
}

void Soporte::setProblema( const string &valorproblema )
{
    int longitud = valorproblema.size();
    longitud = ( longitud < 35 ? longitud : 34 );
    valorproblema.copy( problema, longitud );
    problema[ longitud ] = '\0';
}

void Soporte::setFecha( const string &valorfecha )
{
    int longitud = valorfecha.size();
    longitud = ( longitud < 35 ? longitud : 34 );
    valorfecha.copy( fecha, longitud );
    fecha[ longitud ] = '\0';
}

void Soporte::setEstado( const string &valorEstado )
{
    int longitud = valorEstado.size();
    longitud = ( longitud < 12 ? longitud : 11 );
    valorEstado.copy( estado, longitud );
    estado[ longitud ] = '\0';
}

// Clase friend que nos ayuda con los archivos

ostream &operator<<( ostream &salida, const Soporte &soporte )
{
    salida << "ID:        " << soporte.id << endl
            << "Problema:  " << soporte.problema << endl
            << "Fecha: " << soporte.fecha << endl
            << "Estado:    " << soporte.estado << endl;

    return salida;
}


// Constructor

Soporte::Soporte( void )
{
    for( int i = 0; i < sizeof( id ); id[ i++ ] = '\0' );
    for( int i = 0; i < sizeof( problema ); problema[ i++ ] = '\0' );
    for( int i = 0; i < sizeof( fecha ); fecha[ i++ ] = '\0' );
    for( int i = 0; i < sizeof( estado ); estado[ i++ ] = '\0' );
}


bool Soporte::contiene( const string &idABuscar )
{
    if( buscarId( idABuscar ) == -1 )
        return false;
    return true;
}


Soporte Soporte::pedirRegistro( void )
{
    Soporte registroARetornar;
    string cadena;

    cout << endl << "\t\t\nDAME EL ID DEL REPORTE:";
    fflush( stdin );
    getline( cin, cadena );
    while( contiene( cadena ) || cadena.size() == 0 )
    {
        cout << "Ese ID ya existe o la cadena es invalida: ";
        fflush( stdin );
        getline( cin, cadena );
    }
    registroARetornar.setId( cadena );

    cout << "\t\t\nCUAL ES EL PROBLEMA?: ";
    fflush( stdin );
    getline( cin, cadena );
    registroARetornar.setProblema( cadena );

    cout << "\t\t\nFECHA DEL REPORTE: ";
    fflush( stdin );
    getline( cin, cadena );
    registroARetornar.setFecha( cadena );

    cout << "\t\t\nESTADO DEL PRODUCTO:";
    fflush( stdin );
    getline( cin, cadena );
    registroARetornar.setEstado( cadena );

    return registroARetornar;
}



void Soporte::genera( void )
{
    Soporte promo;
    int contador = 0;
    ofstream file( "dispersion2.txt", ios::out );
    if( !file )
        cout << "No se pudo crear el archivo" << endl;
    else
        for( int i = 0; i < NUMREGISTROS; i++ )
        {
        	// indica cuantos registros hay en el contenedor
        	file.write( ( char * ) &contador, sizeof( int ) );
        	for( int j = 0; j < CONTENEDOR; j++ )
            	file.write( ( char * ) &promo, sizeof( Soporte ) );
        }
    file.close();
}


int Soporte::dispersion( const char llave[ 12 ] )
{
    // llena la el sobrante de la llave con espacios
    char llaveCopia[ 12 ];
    strcpy( llaveCopia, llave );
    if( strlen( llaveCopia ) < 12 )
        for( int i = strlen( llaveCopia ); i < 12; i++ )
            llaveCopia[ i ] = ' ';
    llaveCopia[ 12 ] = '\0';

    // realiza el algoritmo
    long sum = 0;
    int j = 0;
    while( j < 12 )
    {
        sum = ( sum + 100 * llaveCopia[ j ] + llaveCopia[ j + 1 ] )  % 20000;
        j += 2;
    }
    return ( sum % 99 ); // retorna la posici�n donde se guardar� el registros.
}

// retorna la posici�n donde se encontro el registro
long int Soporte::buscarId( const string &idABuscar )
{
    Soporte promo;
    int contador, posIndice;
    long int posByte;

    ifstream file( "dispersion2.txt", ios::in );
    if( !file )
    {
        cout << "El archivo no existe" << endl;
        file.close();
        return -1;
    }

    posIndice = dispersion( idABuscar.c_str() );
    posByte = posIndice * ( ( sizeof( Soporte ) * CONTENEDOR ) + sizeof( int ) );
    file.seekg( posByte, ios::beg );
    file.read( ( char * ) &contador, sizeof( int ) );
    if( contador > 0 )
    {
        for( int i = 0; i < CONTENEDOR; i++ )
        {
            file.read( ( char * ) &promo, sizeof( Soporte ) );
            if( strcmp( promo.id, idABuscar.c_str() ) == 0 )
            {
                posByte = ( long )file.tellg() - sizeof( Soporte );
                file.close();
                return posByte;
            }
        }
    }

    file.close();
    return -1;
}


bool Soporte::agregar( const Soporte &nuevaSoporte )
{
    Soporte promo;
    string cadena;
    int posIndice, contador;
    long int posByte;
    string idString = nuevaSoporte.id;

    if( contiene( idString ) )
        return false;

    fstream file( "dispersion2.txt", ios::in | ios::out );
    posIndice = dispersion( nuevaSoporte.id );
    cout << "Se guardara en la posicion indice: " << posIndice << endl;
    posByte = posIndice * ( sizeof( Soporte ) * CONTENEDOR + sizeof( int ) );
    file.seekg( posByte, ios::beg );
    file.read( ( char * ) &contador, sizeof( int ) ); // lee el numero de registros en el contador
    if( contador < CONTENEDOR ) // si el contenedor no esta lleno
    {
        // aumenta el contador y lo escribe
        contador++;
        file.seekg( posByte, ios::beg );
        file.write( ( char * ) &contador, sizeof( int ) );

        // escribe el nuevo registro en el contenedor
        for( int i = 0; i < CONTENEDOR; i++ )
        {
            file.read( ( char * ) &promo, sizeof( Soporte ) );
            if( promo.id[ 0 ] == '\0' )
            {
                file.seekg( ( long )file.tellg() - sizeof( Soporte ), ios::beg );
                file.write( ( char * ) &nuevaSoporte, sizeof( Soporte ) );
                file.close();
                return true;
            }
        }

    }
    else
        cout << endl << "No hay mas espacio para este registro" << endl;
    file.close();
    return false;
}

void Soporte::mostrar( void )
{
    Soporte promo;
    int contador;
    long int posByte;

    ifstream file( "dispersion2.txt", ios::in );
    if( !file )
        cout << "No existe el archivo" << endl;
    else
    {
        cout << endl;
        for( int i = 0; i < NUMREGISTROS; i++ )
        {
            file.read( ( char * ) &contador, sizeof( int ) );
            if( contador > 0 )
            {
                for( int j = 0; j < CONTENEDOR; j++ )
                {
                    file.read( ( char * ) &promo, sizeof( Soporte ) );
                    if( promo.id[ 0 ] != '\0' )
                        cout << promo << endl;
                }
            }
            else
                file.seekg( sizeof( Soporte ) * CONTENEDOR, ios::cur );
        }
    }
    file.close();
}

bool Soporte::buscar( const string &idABuscar, Soporte &SoporteEncontrada )
{
    long int posByte;

    if( !contiene( idABuscar ) )
        return false;

    ifstream file( "dispersion2.txt", ios::in );
    if( !file )
    {
        cout << "El archivo no existe" << endl;
        file.close();
        return false;
    }

    posByte = buscarId( idABuscar );
    file.seekg( posByte, ios::beg );
    file.read( ( char * ) &SoporteEncontrada, sizeof( Soporte ) );
    file.close();
    return true;
}

bool Soporte::modificar( const string &idAModificar, const Soporte &SoporteNueva )
{
    Soporte registroLimpio, promo;
    int posIndiceAntiguo, posIndiceNuevo, contador;
    long int posByteAntiguo, posByteNuevo;

    if( !contiene( idAModificar ) )
        return false;

    fstream file( "dispersion2.txt", ios::in | ios::out );
    if( !file )
    {
        cout << "El archivo no exite" << endl;
        file.close();
        return false;
    }

    posIndiceAntiguo = dispersion( idAModificar.c_str() );
    posByteAntiguo = buscarId( idAModificar );
    posIndiceNuevo = dispersion( SoporteNueva.id );
    posByteNuevo = posIndiceNuevo * ( sizeof( Soporte ) * CONTENEDOR + sizeof( int ) );

    if( posByteAntiguo == posByteNuevo )
    {
        file.seekg( posByteAntiguo, ios::beg );
        file.write( ( char * ) &SoporteNueva, sizeof(  Soporte) );
    }
    else
    {
        // quita el registro antiguo y resta uno al contador del contenedor
        file.seekg( posByteAntiguo, ios::beg );
        file.write( ( char * ) &registroLimpio, sizeof( Soporte ) );
        posByteAntiguo = posIndiceAntiguo * ( sizeof( Soporte ) * CONTENEDOR + sizeof( int ) );
        file.seekg( posByteAntiguo, ios::beg );
        file.read( ( char * ) &contador, sizeof( int ) );
        contador--;
        file.seekg( posByteAntiguo, ios::beg );
        file.write( ( char * ) &contador, sizeof( int ) );

        // intenta meter el nuevo registro en la nueva posicion
        file.seekg( posByteNuevo, ios::beg );
        file.read( ( char * ) &contador, sizeof( int ) );
        if( contador < CONTENEDOR )
        {
            // aumenta el contador y lo escribe
            contador++;
            file.seekg( posByteNuevo, ios::beg );
            file.write( ( char * ) &contador, sizeof( int ) );

            // escribe el nuevo registro en el contenedor
            for( int i = 0; i < CONTENEDOR; i++ )
            {
                file.read( ( char * ) &promo, sizeof( Soporte ) );
                if( promo.id[ 0 ] == '\0' ) // si el lugar no esta ocupado
                {
                    file.seekg( ( long )file.tellg() - sizeof( Soporte ), ios::beg );
                    file.write( ( char * ) &SoporteNueva, sizeof( Soporte ) );
                    file.close();
                    return true;
                }
            }
        }
        else // el contenedor esta lleno
            return false;
    }
} // fin funcion modificar

bool Soporte::eliminar( const string &idAEliminar, Soporte &destinoEliminado )
{
    Soporte promo;
    int posIndice, posByte, contador;

    if( !contiene( idAEliminar ) )
        return false;

    fstream file( "dispersion2.txt", ios::in | ios::out );
    if( !file )
    {
        cout << "El archivo no exite" << endl;
        file.close();
        return false;
    }

    posIndice = dispersion( idAEliminar.c_str() );
    posByte = buscarId( idAEliminar );

    file.seekg( posByte, ios::beg );
    file.read( ( char * ) &destinoEliminado, sizeof(  Soporte) );
    file.seekg( posByte, ios::beg );
    file.write( ( char * ) &promo, sizeof(  Soporte) );

    posByte = posIndice * ( sizeof( Soporte ) * CONTENEDOR + sizeof( int ) );
    file.seekg( posByte, ios::beg );
    file.read( ( char * ) &contador, sizeof( int ) );
    contador--;
    file.seekg( posByte, ios::beg );
    file.write( ( char * ) &contador, sizeof( int ) );
    file.close();
    return true;
}


void Soporte::menuOpc( void )
{
    Soporte soporte, SoporteBuscar, SoporteModificar, SoporteEliminar, SoporteAgregar;
    string idABuscar, idAModificar, idAEliminar;
    char opcion, op;

    soporte.genera();
    system( "cls" );

    do{
        cout<<"\n\n\t\tB I E N V E N I D O  A L  S O P O R T E  T E C N I C O\n\n";
        cout<<"\n\n\t\tSeleccione una opcion\n\n" << endl
            << "\t\t|1| Agregar"   << endl
            << "\t\t|2| Mostrar"   << endl
            << "\t\t|3| Buscar"    << endl
            << "\t\t|4| Modificar" << endl
            << "\t\t|5| Eliminar"  << endl
            << "\t\t|6| Salir"     << endl
            << endl;
        cin >> opcion;
        switch( opcion )
        {
          case '1':
            system( "cls" );
            SoporteAgregar = soporte.pedirRegistro();
            if( soporte.agregar( SoporteAgregar ) )
                cout << "Cliente agregado con exito" << endl;
            else
                cout << "No se agrego la soporte" << endl;
            break;

          case '2':
            system( "cls" );
            soporte.mostrar();
            break;

          case '3':
            system( "cls" );
            cout << "Ingrese el ID de la soporte a buscar: ";
            fflush( stdin );
            getline( cin, idABuscar );
            if( soporte.buscar( idABuscar, SoporteBuscar ) )
                cout << endl << SoporteBuscar << endl;
            else
                cout << "No existe el registro" << endl;
            break;

          case '4':
            system( "cls" );
            cout << "Ingrese el ID de la soporte a modificar: ";
            fflush( stdin );
            getline( cin, idAModificar );
            if( soporte.buscar( idAModificar, SoporteBuscar ) )
            {
                cout << endl << SoporteBuscar << endl;
                cout << "Desea modificarlo?" << endl;
                cout << "1) Si" << endl;
                cout << "2) No" << endl;
                cin >> op;

                if( op == '1' )
                {
                    SoporteModificar = soporte.pedirRegistro();
                    if( soporte.modificar( idAModificar, SoporteModificar ) )
                        cout << endl << "Soporte modificada con exito" << endl;
                    else
                        cout << endl << "No se pudo modificar" << endl;
                }
            }
            else
                cout << "No existe el registro" << endl;
            break;

          case '5':
            system( "cls" );
            cout << "Ingrese el ID de la Soporte a eliminar: ";
            fflush( stdin );
            getline( cin, idAEliminar );
            if( soporte.buscar( idAEliminar, SoporteBuscar ) )
            {
                cout << endl << SoporteBuscar << endl;
                cout << "Desea eliminarlo?" << endl;
                cout << "1) Si" << endl;
                cout << "2) No" << endl;
                cin >> op;

                if( op == '1' )
                    if( soporte.eliminar( idAEliminar, SoporteEliminar ) )
                        cout << endl << SoporteEliminar << endl << "SE ELIMINO CORRECTAMENTE" << endl;
                    else
                        cout << "NO SE PUDO ELIMINAR" << endl;
            }
            else
                cout << "No existe el registro" << endl;
            break;
        }
        cout << endl;
        system("Pause");
        system( "cls" );
    }while(opcion != '6');
}
